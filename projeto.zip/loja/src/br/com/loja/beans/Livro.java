package br.com.loja.beans;

public class Livro {

}
