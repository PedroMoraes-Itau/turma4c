function exibir(){
    window.alert("Hello World");
}

function verificarNumero(){
    var numero = window.prompt("Digite um numero");
    var resultado = parseInt(numero)%2;
    if (resultado==0){
        window.alert("O número é par");
    }else{
        window.alert("O número é impar");
    }
}

function somarNumeros(valor1, valor2){
    var resultado = parseInt(valor1)+parseInt(valor2);
    return resultado;
}

function calcular(){
    operacoes = document.getElementsByName("optCalcular");
    if (operacoes[0].checked){
        document.getElementById("txtResultado").value = 
            parseInt(document.getElementById("txtValor1").value)+
            parseInt(document.getElementById("txtValor2").value);
    }else if(operacoes[1].checked){
        document.getElementById("txtResultado").value = 
        parseInt(document.getElementById("txtValor1").value)-
        parseInt(document.getElementById("txtValor2").value);       
    }else if(operacoes[2].checked){
        document.getElementById("txtResultado").value = 
        parseInt(document.getElementById("txtValor1").value)*
        parseInt(document.getElementById("txtValor2").value);       
    }else if(operacoes[3].checked){
        document.getElementById("txtResultado").value = 
        parseInt(document.getElementById("txtValor1").value)/
        parseInt(document.getElementById("txtValor2").value);       
    }
}